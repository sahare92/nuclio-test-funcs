class B(object):

    @staticmethod
    def get_sum(numbers):
        return sum(numbers)
