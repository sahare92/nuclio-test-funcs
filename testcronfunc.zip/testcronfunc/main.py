import json

def handler(context, event):
    body = "nothing yet"
    if isinstance(body, bytes):
        body = json.loads(body)
    context.logger.debug_with("got response body", body=body)

