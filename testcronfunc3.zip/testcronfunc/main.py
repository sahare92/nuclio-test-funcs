import json

def handler(context, event):
    body = json.loads(event.body)
    context.logger.debug_with("got response body", body=body)
