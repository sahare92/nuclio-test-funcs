import json

def handler(context, event):
    try:
    	context.logger.debug_with("event body is", event_body=event.body)
    except:
    	pass
    body = json.loads(event.body)
    context.logger.debug_with("got response body", body=body)
